package projeto.academiajava.classes;


//Interface de Opera��es
public interface ContaOperacoes {
	double depositar(double valor);

	boolean sacar(double valor);
}
